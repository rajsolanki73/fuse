import { Component, OnInit } from '@angular/core';

@Component({
    selector   : 'fuse-file-manager-main-sidenav',
    templateUrl: './main.component.html',
    styleUrls  : ['./main.component.scss']
})
export class FuseFileManagerMainSidenavComponent implements OnInit
{
    selected: any;

    constructor()
    {

    }

    ngOnInit()
    {
    }

}
