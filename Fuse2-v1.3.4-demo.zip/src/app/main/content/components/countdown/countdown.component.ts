import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-countdown-docs',
    templateUrl: './countdown.component.html',
    styleUrls  : ['./countdown.component.scss']
})
export class FuseCountdownDocsComponent
{
    constructor()
    {

    }
}
