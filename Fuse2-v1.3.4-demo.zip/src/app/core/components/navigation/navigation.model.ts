export interface FuseNavigationModelInterface
{
    model: any[];
}

